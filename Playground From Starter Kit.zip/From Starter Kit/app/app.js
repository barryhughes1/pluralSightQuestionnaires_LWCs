import { LightningElement, track, api } from 'lwc';

export default class App extends LightningElement {}
